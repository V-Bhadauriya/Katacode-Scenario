from pyspark.sql import SparkSession
from pyspark.sql.functions import col, expr
from delta.tables import DeltaTable
import shutil


bucket = "s3a://vivek/sample/"

spark = SparkSession.builder \
    .appName("quickstart") \
    .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension") \
    .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog") \
    .getOrCreate()

spark.sparkContext.setLogLevel("ERROR")

# Create a table
print("############# Creating a table ###############")
data = spark.range(0, 5)
data.write.format("delta").save(bucket)

# Read the table
print("############ Reading the table ###############")
df = spark.read.format("delta").load(bucket)
df.show()

# Upsert (merge) new data
print("########### Upsert new data #############")
newData = spark.range(0, 20)

deltaTable = DeltaTable.forPath(spark, bucket)

deltaTable.alias("oldData")\
    .merge(
    newData.alias("newData"),
    "oldData.id = newData.id")\
    .whenMatchedUpdate(set={"id": col("newData.id")})\
    .whenNotMatchedInsert(values={"id": col("newData.id")})\
    .execute()

deltaTable.toDF().show()

# Update table data
print("########## Overwrite the table ###########")
data = spark.range(5, 10)
data.write.format("delta").mode("overwrite").save(bucket)
deltaTable.toDF().show()

deltaTable = DeltaTable.forPath(spark, bucket)

# Update every even value by adding 100 to it
print("########### Update to the table(add 100 to every even value) ##############")
deltaTable.update(
    condition=expr("id % 2 == 0"),
    set={"id": expr("id + 100")})

deltaTable.toDF().show()

# Delete every even value
print("######### Delete every even value ##############")
deltaTable.delete(condition=expr("id % 2 == 0"))
deltaTable.toDF().show()

# Read old version of data using time travel
print("######## Read old data using time travel ############")
df = spark.read.format("delta").option("versionAsOf", 0).load(bucket)
df.show()
print("######### Stoping Spark Context ##############")
spark.stop()
